$Id: README-SCHEMA.txt,v 1.1 2006/05/31 09:42:51 neysseri Exp $
The following files contained witin this folder are covered by license terms
documented in docs/licenses/sun-specs.txt of the distribution. 

application_1_4.xsd
application-client_1_4.xsd
connector_1_5.xsd
ejb-jar_2_1.xsd
j2ee_1_4.xsd
j2ee_jaxrpc_mapping_1_1.xsd
j2ee_web_services_1_1.xsd
j2ee_web_services_client_1_1.xsd
jsp_2_0.xsd
web-app_2_4.xsd
web-jsptaglibrary_2_0.xsd

More details on using these J2EE Schemas are available at:
java.sun.com/xml/ns/j2ee/#usage
